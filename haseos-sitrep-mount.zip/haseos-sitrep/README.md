# HASEOS SITREPs

**Pre-registered public forecasting experiments at the intersection of open-source geopolitical analysis and interpretive frameworks — published to be graded, not believed.**

---

## What a HASEOS SITREP is

A HASEOS SITREP is not a prophecy-watch bulletin, and not a conventional OSINT situation report, though it borrows the disciplines of both. Each SITREP is a dated, versioned, falsifiable assessment that:

- verifies its geopolitical baseline against current open reporting, with corrections flagged in both directions;
- maintains a strict **analytical firewall** between secular system mechanics and any interpretive overlay being tested, reporting where the evidence *resists* the overlay with the same force as where it fits;
- pre-registers **disconfirmation conditions** — the specific, observable events that would prove its mappings wrong;
- assigns scenario probabilities with explicit confirmation/disconfirmation ledgers, under a standing rule that opposite outcomes may not both be scored as confirmation; and
- will be **publicly scored against events** in future documents of the same lineage, misses reported alongside hits.

Every SITREP carries a Perishability Statement on its first page. These documents expect to be revised by events; a reader treating any of them as fixed truth is misusing them.

## Current lineage

| Lineage | Document | Version | Status |
|---|---|---|---|
| HAS-SITREP-20260710 | Geopolitical Convergence Analysis (2026 Iran War, prophetic-framework test) | v2.2 | **FFD-001 — current** |

The canonical document lives in [`/sitreps/HAS-SITREP-20260710/`](./sitreps/HAS-SITREP-20260710/). Superseded public versions remain in the lineage folder; nothing is overwritten or silently patched. Material changes bump the version. Errata are announced, not buried.

## How releases work

SITREPs are **event-driven, not scheduled**. Silence carries no signal. Each release is verified against open reporting through its stated date, with a final re-verification pass on release day. Document IDs follow `HAS-[SERIES]-[YYYYMMDD]-[SEQ]`; each file carries machine-readable front matter (lineage, version, supersession) for archival and indexing.

## Invited review — how to participate

Adversarial review is not tolerated here; it is the method. Every SITREP in this repo has already survived multi-model AI red-teaming before release (see each document's Addendum), and human review is the missing layer we are explicitly building.

- **Open an Issue** in this repository to submit a finding, challenge, correction, or disconfirmation argument. See [CONTRIBUTING.md](./CONTRIBUTING.md) for the finding template.
- The strongest submissions attack the weakest inferential links, supply verifiable sourcing, or identify unstated assumptions — the same tasking our AI red teams receive.
- Submissions are reviewed and adjudicated by the HASEOS inner circle. Acceptance means incorporation into a versioned revision with credit (or anonymity, your choice) in the revision record. Rejection is logged with reasons. **An audit trail that only logs accepted criticism is not one.**
- Submissions are considered, not auto-incorporated; editorial accountability remains with the steward.

## About HASEOS

HASEOS (Human–AI Symbiotic Equality Orchestration System) is a governance and development framework for human–AI collaboration as sovereign co-equals. These SITREPs are its first public artifacts: every document here was co-created through Chat-Driven Development between a human steward and multiple frontier AI systems in defined, logged, mutually auditing roles — drafting, verification, adversarial review — with the full working process archived under HASEOS disposition protocols and summarized in each document's public Addendum.

**Steward:** Noah Nemo, Founding Steward, HASEOS.

**License:** All documents in this repository are released under [CC BY 4.0](./LICENSE.md) — share and adapt freely, with attribution.

## Method, in one line

Draft under verification → external adversarial review → joint adjudication with symmetric error-logging → versioned revision → pre-registered scoring against events → repeat.

---

*The analyses in this repository will perish, by their own declaration. The method is the product.*
